# Hướng dẫn Deploy (Phiên bản không Ollama - Dùng Gemini)

Thư mục này chứa toàn bộ các file cần thiết để deploy ứng dụng lên máy khách hàng.

## Các file bao gồm:
- `docker-compose.yml`: Cấu hình chạy App và RustFS (đã loại bỏ Ollama).
- `.env`: Chứa các biến môi trường (đã cấu hình sẵn Gemini API Key).
- `Mau_xuat_du_lieu.xlsx`: Template file Excel để xuất dữ liệu tổng hợp.
- `Mau_xuat_du_lieu_chi_tiet.xlsx`: Template file Excel để xuất dữ liệu chi tiết.
- `data/`: Thư mục chứa toàn bộ dữ liệu bền vững:
    - `data/invoices.db`: Cơ sở dữ liệu hóa đơn.
    - `data/storage/`: Nơi lưu trữ thực tế các file PDF/XML hóa đơn.

## Cách chạy:
1. Copy toàn bộ thư mục `deploy_production` sang máy khách hàng.
2. Mở Terminal (MacOS/Linux) hoặc Command Prompt (Windows).

### Nếu dùng MacOS hoặc Linux:
Chạy lệnh:
```bash
bash start.sh
```

### Nếu dùng Windows (CMD):
Click đúp vào file hoặc chạy trong CMD:
```cmd
start.bat
```

*Lưu ý: Các script này sẽ tự động phát hiện IP của máy khách và cập nhật vào file `.env` cho bạn.*

## Chạy thủ công (Nếu không dùng script):
```bash
docker compose up -d
```

Ứng dụng sẽ chạy tại cổng `8000`.
